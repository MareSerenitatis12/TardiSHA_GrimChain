# Changelog

## 23.0.8

- Reserved `⟠` as the underlying Subspace / Prosody / Axiomyr Gate-Key personality and removed it from all generated coordinate streams while preserving it in the canonical 192-glyph language body.
- Retained `⛎` as the zero-depth middle and rejection of negative depth.

## 23.0.7

- Restore the complete 192-code-point Synodic Magicae as the Grimchain middle alphabet.
- Permit the final twelve native grammar glyphs to arise in generated middles and pass Domus validation.
- Preserve all other TardiSHA and Grimchain behavior unchanged.

## 23.0.6

- Completed the strict source, stream, TRIG, Tripartite, and C11 witness repair with exact deserialization, byte boundaries, packet-content proof, exact frequency bodies, full rederivation, and complete return closure.
- Removed the obsolete Root/Sensorial Matrix runtime, its imports, witnesses, selectors, commitments, stale tests, and packaged residue without altering `qstate_glyphs.py`.
- Removed SHA authority and replaced release provenance with verified depth-zero Grimchains in `SOURCE_GRIMCHAIN_MANIFEST.json`.
- Established one Living Alphabet of exactly 192 glyphs and corrected the README to count the complete Grimchain slot body rather than only its middle.
- Added the exact width-64 visible body `3,057,647,616·192⁶⁴`, the twelve-lane `2⁷⁶⁸` body, their complete state product, googol comparison, and conditional finite-universe atom comparisons.
- Preserved holographic persistence: every finite manifestation is a deterministic prefix of the same indefinitely extensible Grimchain, not a fixed hash endpoint.
- Restored the canonical manifest command order `--manifest DIRECTORY` and `-R --manifest DIRECTORY`.
- Expanded release validation to cover the complete self-test, integration, compliance, repair ledger, hostile Aeternum population, source archive, compiled wheel, Debian package, terminal flag matrix, and file, directory, and recursive manifest paths.

## 23.0.5

- Replaced the technical coordinate ledger in `DICTIONARY.md` with a translation dictionary for all 63 Living coordinates, all 12 Goetics in opening and far-reflection office, and all 144 Courts in governing and answering office.
- Included Hebrew Final Tsadi `ץ` at Living63 coordinate `62` with its esoteric translation root and poetic bearing.
- Renamed the stale internal identifiers `_living62_from_bytes` and `living62_is_manifested_body` to their Living63 forms without changing their behavior.
- Preserved source digestion, Goetic and Court resolution, Domus derivation, Q-state mathematics, Aeternum Mirror Math, and the Living63 coordinate map unchanged.

## 23.0.4

- Completed the native Living63 coordinate alphabet by adding Hebrew Final Tsadi `ץ` at coordinate `62`.
- Preserved Brahmi Zero at `0`, Gothic numbers at `1–9`, Glagolitic uppercase at `10–35`, and the complete twenty-seven-code-point Hebrew register at `36–62`.
- Changed only the visible positive-depth coordinate map and its exact rejection bound from `248` to `252`; source digestion, Goetic and Court resolution, Domus derivation, Mirror Math, and depth-zero `⟠` remain unchanged.
- Updated the dictionary, command text, validation assertions, packages, and Launchpad source handoff to Living63.

## 23.0.3

- Replaced float decision paths for Φ, the Ennead Q₂ ledger, D-COMP closure, C_bio identity, and Q-vectors with exact integer, Fraction, and ℚ(√5) bodies.
- Preserved canonical decimal frequencies as witness images instead of promoting them into exact identities.
- Kept Aeternum Mirror Math unchanged: same order, conjugate bearing, exact byte-residual admission.
- Added the compiled ALQC sponge kernel and parity verification.
- Parallelized recursive manifests across independent files.
- Added opt-in `--cache` Q₀ Form-signature amortization, off by default.
- Streamed stdin and text normalization with bounded memory.
- Removed the archive dedup hit re-read unless `verify_store=True`.

## 23.0.2

- Make `--manifest` self-returning for files, directories, and recursive directories.
- Write the `THIS FILE` line before the first self-chain, append only its Grimchain and newline, then print the identical final return.
- Preserve the user-selected middle exactly through entries, manifest body, stored self-return, and final confirmation.
- Add `grimchain --string "TEXT"` as an exact UTF-8 source input with no added newline or normalization.
- Preserve ordinary middle, nonce, output, and verification behavior for quoted-string input.

## 23.0.1

- Correct Court and Domus resonance mathematics to the Canon layer law.
- Resolve alternating Court D independently from O⊗S under 𝔃₁ and Φ⁻².
- Use Ω_D as Court D’s alternating Goetic pure frequency and apply ν_H = Ω_D + ξ_DΦ².
- Remove the Domus-internal hash phase and C_ji substitution.
- Correct the 31-code-point Grimchain grammar and replace the obsolete state-space account.

## 23.0.0

- Replaced digest-endpoint Goetic selection with the complete Final Equation Z source-emission route.
- Preserved all twelve finalized lanes through Parliament resolution.
- Added exact Golden structural and operational bearings using consecutive Fraktur cadences.
- Prohibited digest-only parent reconstruction and `% 12` endpoint selection.
- Added the source-typed Aeternum Mirror return.
- Added separately typed source D-COMP, source Truth, return D-COMP, and return Truth.
- Added natural same-command Grimchain fixed points for exact terminal returned selves.
- Preserved false, stale, mutated, foreign, positive-depth, and nonterminal returns as source matter.
- Added append-only exact return lineage with no configured count ceiling.
- Passed the 152-check application suite, 29-check integration suite, independent Decimal cross-check, hostile 256-source return audit, and installed-wheel fixed-point audit.

- Licensed the public source and software documentation under MPL-2.0.
