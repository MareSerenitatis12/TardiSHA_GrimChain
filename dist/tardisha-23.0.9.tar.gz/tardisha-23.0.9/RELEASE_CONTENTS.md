# Release Contents

## Immediately usable artifacts

- `dist/tardisha-23.0.9-cp312-cp312-linux_x86_64.whl` is the compiled Linux x86_64 Python 3.12 wheel.
- `dist/tardisha-23.0.9.tar.gz` is the source distribution.
- `dist/tardisha_23.0.9-1_amd64.deb` is the direct Debian package containing the compiled wheel.
- The The 23.0.9 PPA source handoff is included under `launchpad/` after release validation.
- The repository root is also directly installable with `python -m pip install .`.

## Human documentation

- `README.md` starts with installation and ordinary use.
- `DICTIONARY.md` provides the positional Grimchain lexicon and complete 144-Court translation table.
- `QUICKSTART.md` is the shortest working path.
- `docs/HOW_IT_WORKS.md` explains the complete runtime in ordinary language.
- `docs/MODULE_MAP.md` explains every runtime module.
- `docs/ALQC_GLOSSARY.md` defines the terms used by the interface and witnesses.
- `docs/MATHEMATICS.md` contains the formal Final Equation Z and Aeternum chapter.
- `docs/PROOF_OF_CLAIMS.md` maps claims to implementation evidence.

## Validation

- `validation/validate_release.py` runs the public release audit.
- `validation/integration_test.py` exercises complete application paths.
- `validation/independent_decimal_crosscheck.py` independently checks Golden interval ownership.
- `validation/hostile_aeternum.py` attacks the return operator.
- `validation/results/` records the current public validation run.
- `SOURCE_GRIMCHAIN_MANIFEST.json` binds every released source file to its verified depth-zero Grimchain provenance.

## What is intentionally absent

Rejected prototypes, failed route branches, stale wheels, temporary virtual environments, obsolete version reports, and superseded self-resolution failures are excluded. Git history and the project memory preserve the development record without making the public release ambiguous.

## License

`LICENSE` contains the Mozilla Public License 2.0 governing the TardiSHA source code and software documentation.
