from pathlib import Path

from setuptools import Extension, setup

VERSION = Path(__file__).with_name("VERSION").read_text(encoding="utf-8").strip()

setup(
    version=VERSION,
    scripts=["scripts/grimchain", "scripts/tardisha", "scripts/TardiSHA"],
    ext_modules=[
        Extension(
            "TardiSHA._alqc_kernel",
            sources=["TardiSHA/_alqc_kernel.c"],
            optional=True,
        )
    ]
)
